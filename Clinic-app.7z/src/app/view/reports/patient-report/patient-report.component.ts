import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-patient-report',
  templateUrl: './patient-report.component.html',
  styleUrls: ['./patient-report.component.scss']
})
export class PatientReportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
