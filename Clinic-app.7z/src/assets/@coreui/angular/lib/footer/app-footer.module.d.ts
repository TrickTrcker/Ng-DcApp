export declare class AppFooterModule {
}
