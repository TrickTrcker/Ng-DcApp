export declare const sidebarCssClasses: Array<string>;
export declare const asideMenuCssClasses: Array<string>;
