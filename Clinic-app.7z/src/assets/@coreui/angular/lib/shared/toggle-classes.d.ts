export declare const ToggleClasses: (Toggle: any, ClassNames: any) => void;
