export declare function Replace(el: any): any;
