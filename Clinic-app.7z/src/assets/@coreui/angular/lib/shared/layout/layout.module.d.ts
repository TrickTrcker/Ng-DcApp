export declare class LayoutModule {
}
