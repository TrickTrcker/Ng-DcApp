export declare class AppAsideModule {
}
