export declare class AppHeaderModule {
}
