export declare class AppSidebarModule {
}
