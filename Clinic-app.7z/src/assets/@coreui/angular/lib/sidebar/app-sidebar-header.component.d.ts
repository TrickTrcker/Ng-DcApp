import { ElementRef, OnInit } from '@angular/core';
export declare class AppSidebarHeaderComponent implements OnInit {
    private el;
    constructor(el: ElementRef);
    ngOnInit(): void;
}
