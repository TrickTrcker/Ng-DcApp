import { ElementRef, OnInit } from '@angular/core';
export declare class AppSidebarFooterComponent implements OnInit {
    private el;
    constructor(el: ElementRef);
    ngOnInit(): void;
}
