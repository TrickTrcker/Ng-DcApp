import { ElementRef, OnInit } from '@angular/core';
export declare class AppSidebarFormComponent implements OnInit {
    private el;
    constructor(el: ElementRef);
    ngOnInit(): void;
}
